const express = require('express');
const session = require('express-session');
const mongoose = require('mongoose');
const MongoStore = require('connect-mongo');
const bcrypt = require('bcryptjs');
const path = require('path');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Session with MongoDB store
app.use(session({
  secret: process.env.SESSION_SECRET || 'secret',
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({ mongoUrl: process.env.MONGODB_URI }),
  cookie: {
    secure: false,
    maxAge: 1000 * 60 * 60 * 24,
    httpOnly: true
  }
}));

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('✅ MongoDB Connected'))
  .catch(err => console.error('MongoDB Error:', err));

// ============= SCHEMAS =============

const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,
  role: { type: String, enum: ['user', 'admin', 'technician'], default: 'user' },
  avatar: { type: String, default: '👤' },
  joinDate: { type: Date, default: Date.now }
});

const equipmentSchema = new mongoose.Schema({
  code: String,
  name: String,
  category: String,
  status: { type: String, enum: ['available', 'borrowed', 'maintenance'], default: 'available' },
  location: String,
  dailyPenalty: { type: Number, default: 50 },
  image: { type: String, default: '📦' },
  description: String,
  rating: { type: Number, default: 4.5 }
});

const borrowRequestSchema = new mongoose.Schema({
  requestId: String,
  equipId: { type: mongoose.Schema.Types.ObjectId, ref: 'Equipment' },
  equipName: String,
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  userName: String,
  borrowDate: String,
  dueDate: String,
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  createdAt: { type: Date, default: Date.now }
});

const activeBorrowSchema = new mongoose.Schema({
  borrowId: String,
  equipId: { type: mongoose.Schema.Types.ObjectId, ref: 'Equipment' },
  equipName: String,
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  userName: String,
  borrowDate: String,
  dueDate: String,
  createdAt: { type: Date, default: Date.now }
});

const penaltySchema = new mongoose.Schema({
  penaltyId: String,
  equipName: String,
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  userName: String,
  amount: Number,
  reason: String,
  status: { type: String, enum: ['unpaid', 'paid'], default: 'unpaid' },
  issuedDate: String,
  paidAt: String
});

const maintenanceSchema = new mongoose.Schema({
  ticketId: String,
  equipId: { type: mongoose.Schema.Types.ObjectId, ref: 'Equipment' },
  equipName: String,
  issue: String,
  description: String,
  reportedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  reporterName: String,
  status: { type: String, enum: ['reported', 'in-progress', 'completed'], default: 'reported' },
  reportedAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', userSchema);
const Equipment = mongoose.model('Equipment', equipmentSchema);
const BorrowRequest = mongoose.model('BorrowRequest', borrowRequestSchema);
const ActiveBorrow = mongoose.model('ActiveBorrow', activeBorrowSchema);
const Penalty = mongoose.model('Penalty', penaltySchema);
const Maintenance = mongoose.model('Maintenance', maintenanceSchema);

// ============= SEED DATABASE =============
async function seedDatabase() {
  try {
    const userCount = await User.countDocuments();
    if (userCount > 0) {
      console.log('Database already has data, skipping seed');
      return;
    }

    console.log('🌱 Seeding database...');
    
    const salt = await bcrypt.genSalt(10);
    
    // Create users
    const users = await User.create([
      { name: 'Alex Tamang', email: 'alex@demo.com', password: await bcrypt.hash('123', salt), role: 'user', avatar: '👨‍🎓' },
      { name: 'Pratik Shrestha', email: 'pratik@demo.com', password: await bcrypt.hash('admin123', salt), role: 'admin', avatar: '👑' },
      { name: 'Subash Tiwari', email: 'subash@demo.com', password: await bcrypt.hash('tech123', salt), role: 'technician', avatar: '🔧' },
      { name: 'Binita Rai', email: 'binita@demo.com', password: await bcrypt.hash('123', salt), role: 'user', avatar: '👩‍🎓' },
      { name: 'Sahaj Sharma', email: 'sahaj@demo.com', password: await bcrypt.hash('admin123', salt), role: 'admin', avatar: '👨‍💼' },
      { name: 'Mausham Yadav', email: 'mausham@demo.com', password: await bcrypt.hash('tech123', salt), role: 'technician', avatar: '🛠️' }
    ]);

    // Create equipment
    await Equipment.create([
      { code: 'PRJ-001', name: 'Epson PowerLite Projector', category: 'AV', location: 'Room 301', dailyPenalty: 50, image: '📽️', description: '4000 lumens, 4K support', rating: 4.8 },
      { code: 'CAM-002', name: 'Canon EOS 90D Camera', category: 'Photography', location: 'Media Center', dailyPenalty: 70, image: '📷', description: '32.5MP, 4K video', rating: 4.9 },
      { code: 'LAP-003', name: 'MacBook Pro 16" M2', category: 'Laptops', location: 'IT Dept', dailyPenalty: 100, image: '💻', description: 'M2 Pro, 16GB RAM', rating: 5.0 },
      { code: 'AUD-004', name: 'Shure Wireless Mic', category: 'Audio', location: 'Audio Lab', dailyPenalty: 40, image: '🎤', description: 'Dual wireless system', rating: 4.7 },
      { code: 'STB-005', name: 'DJI Ronin Gimbal', category: 'Stabilizers', location: 'Studio', dailyPenalty: 80, image: '🎥', description: '3-axis gimbal', rating: 4.8 },
      { code: 'VR-006', name: 'Meta Quest 3', category: 'VR/AR', location: 'VR Lab', dailyPenalty: 120, image: '🥽', description: 'Mixed reality headset', rating: 4.9 },
      { code: 'DSG-007', name: 'Wacom Tablet', category: 'Design', location: 'Design Lab', dailyPenalty: 60, image: '✏️', description: 'Drawing tablet', rating: 4.6 },
      { code: 'ACC-008', name: 'Tripod Stand', category: 'Accessories', location: 'Storage', dailyPenalty: 20, image: '🎬', description: 'Heavy duty tripod', rating: 4.5 }
    ]);

    console.log('✅ Database seeded successfully!');
  } catch (error) {
    console.error('Seed error:', error);
  }
}

// ============= MIDDLEWARE =============
const requireAuth = (req, res, next) => {
  if (!req.session.user) return res.status(401).json({ error: 'Please login first' });
  next();
};

const requireRole = (roles) => (req, res, next) => {
  if (!req.session.user) return res.status(401).json({ error: 'Please login first' });
  if (!roles.includes(req.session.user.role)) return res.status(403).json({ error: 'Access denied' });
  next();
};

// ============= AUTH ROUTES =============
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password, role } = req.body;
    const user = await User.findOne({ email, role });
    
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });
    
    req.session.user = {
      id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      avatar: user.avatar
    };
    
    res.json({ success: true, user: req.session.user });
  } catch (error) {
    res.status(500).json({ error: 'Login failed' });
  }
});

app.post('/api/auth/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

app.get('/api/auth/me', (req, res) => {
  if (req.session.user) {
    res.json({ authenticated: true, user: req.session.user });
  } else {
    res.json({ authenticated: false, user: null });
  }
});

// ============= EQUIPMENT ROUTES =============
app.get('/api/equipment', async (req, res) => {
  try {
    const { category, status } = req.query;
    let query = {};
    if (category && category !== 'all') query.category = category;
    if (status && status !== 'all') query.status = status;
    
    const equipment = await Equipment.find(query);
    res.json({ success: true, equipment });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch equipment' });
  }
});

app.post('/api/equipment', requireRole(['admin']), async (req, res) => {
  try {
    const { name, category, location, dailyPenalty, description } = req.body;
    const count = await Equipment.countDocuments();
    const code = `${category.substring(0,3).toUpperCase()}-${String(count + 1).padStart(3, '0')}`;
    
    const equipment = await Equipment.create({
      code, name, category, location, 
      dailyPenalty: parseInt(dailyPenalty) || 50,
      description
    });
    
    res.json({ success: true, equipment });
  } catch (error) {
    res.status(500).json({ error: 'Failed to add equipment' });
  }
});

app.delete('/api/equipment/:id', requireRole(['admin']), async (req, res) => {
  try {
    await Equipment.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete' });
  }
});

// ============= BORROW ROUTES =============
app.post('/api/borrow/request', requireAuth, async (req, res) => {
  try {
    const { equipId, equipName } = req.body;
    const equipment = await Equipment.findById(equipId);
    
    if (!equipment || equipment.status !== 'available') {
      return res.status(400).json({ error: 'Equipment not available' });
    }
    
    const borrowDate = new Date().toISOString().slice(0,10);
    const dueDate = new Date(Date.now() + 7*86400000).toISOString().slice(0,10);
    
    const request = await BorrowRequest.create({
      requestId: `REQ${Date.now()}`,
      equipId,
      equipName,
      userId: req.session.user.id,
      userName: req.session.user.name,
      borrowDate,
      dueDate
    });
    
    res.json({ success: true, request });
  } catch (error) {
    res.status(500).json({ error: 'Request failed' });
  }
});

app.get('/api/borrow/requests', requireRole(['admin']), async (req, res) => {
  try {
    const requests = await BorrowRequest.find({ status: 'pending' });
    res.json({ success: true, requests });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch' });
  }
});

app.post('/api/borrow/approve/:requestId', requireRole(['admin']), async (req, res) => {
  try {
    const request = await BorrowRequest.findOne({ requestId: req.params.requestId });
    if (!request) return res.status(404).json({ error: 'Request not found' });
    
    const equipment = await Equipment.findById(request.equipId);
    if (!equipment || equipment.status !== 'available') {
      return res.status(400).json({ error: 'Equipment no longer available' });
    }
    
    equipment.status = 'borrowed';
    await equipment.save();
    
    await ActiveBorrow.create({
      borrowId: `BOR${Date.now()}`,
      equipId: request.equipId,
      equipName: request.equipName,
      userId: request.userId,
      userName: request.userName,
      borrowDate: request.borrowDate,
      dueDate: request.dueDate
    });
    
    request.status = 'approved';
    await request.save();
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Approval failed' });
  }
});

app.get('/api/borrow/active', requireAuth, async (req, res) => {
  try {
    let query = {};
    if (req.session.user.role === 'user') {
      query.userId = req.session.user.id;
    }
    const borrows = await ActiveBorrow.find(query);
    res.json({ success: true, borrows });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch' });
  }
});

app.post('/api/borrow/return/:borrowId', requireAuth, async (req, res) => {
  try {
    const borrow = await ActiveBorrow.findOne({ borrowId: req.params.borrowId });
    if (!borrow) return res.status(404).json({ error: 'Not found' });
    
    const equipment = await Equipment.findById(borrow.equipId);
    if (equipment) {
      equipment.status = 'available';
      await equipment.save();
    }
    
    const today = new Date().toISOString().slice(0,10);
    let penaltyAmount = 0;
    
    if (today > borrow.dueDate) {
      const daysLate = Math.ceil((new Date(today) - new Date(borrow.dueDate)) / 86400000);
      penaltyAmount = daysLate * (equipment?.dailyPenalty || 50);
      
      if (penaltyAmount > 0) {
        await Penalty.create({
          penaltyId: `PEN${Date.now()}`,
          equipName: borrow.equipName,
          userId: borrow.userId,
          userName: borrow.userName,
          amount: penaltyAmount,
          reason: `${daysLate} day(s) late`,
          issuedDate: today
        });
      }
    }
    
    await ActiveBorrow.deleteOne({ borrowId: req.params.borrowId });
    res.json({ success: true, penalty: penaltyAmount > 0 ? { amount: penaltyAmount } : null });
  } catch (error) {
    res.status(500).json({ error: 'Return failed' });
  }
});

// ============= PENALTY ROUTES =============
app.get('/api/penalties', requireAuth, async (req, res) => {
  try {
    let query = {};
    if (req.session.user.role === 'user') {
      query.userId = req.session.user.id;
    }
    const penalties = await Penalty.find(query);
    res.json({ success: true, penalties });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch' });
  }
});

app.post('/api/penalties/pay/:penaltyId', requireAuth, async (req, res) => {
  try {
    await Penalty.findOneAndUpdate(
      { penaltyId: req.params.penaltyId },
      { status: 'paid', paidAt: new Date().toISOString().slice(0,10) }
    );
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Payment failed' });
  }
});

// ============= MAINTENANCE ROUTES =============
app.post('/api/maintenance/report', requireAuth, async (req, res) => {
  try {
    const { equipId, equipName, issue, description } = req.body;
    
    const equipment = await Equipment.findById(equipId);
    if (equipment) {
      equipment.status = 'maintenance';
      await equipment.save();
    }
    
    const ticket = await Maintenance.create({
      ticketId: `MNT${Date.now()}`,
      equipId,
      equipName,
      issue,
      description,
      reportedBy: req.session.user.id,
      reporterName: req.session.user.name
    });
    
    res.json({ success: true, ticket });
  } catch (error) {
    res.status(500).json({ error: 'Report failed' });
  }
});

app.get('/api/maintenance/tickets', requireRole(['admin', 'technician']), async (req, res) => {
  try {
    const tickets = await Maintenance.find();
    res.json({ success: true, tickets });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch' });
  }
});

app.put('/api/maintenance/tickets/:ticketId', requireRole(['admin', 'technician']), async (req, res) => {
  try {
    const { status } = req.body;
    const ticket = await Maintenance.findOne({ ticketId: req.params.ticketId });
    
    if (ticket) {
      ticket.status = status;
      await ticket.save();
      
      if (status === 'completed') {
        const equipment = await Equipment.findById(ticket.equipId);
        if (equipment && equipment.status === 'maintenance') {
          equipment.status = 'available';
          await equipment.save();
        }
      }
    }
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Update failed' });
  }
});

// ============= DASHBOARD STATS =============
app.get('/api/dashboard/stats', requireAuth, async (req, res) => {
  try {
    const stats = {
      totalEquipment: await Equipment.countDocuments(),
      availableEquipment: await Equipment.countDocuments({ status: 'available' }),
      borrowedEquipment: await Equipment.countDocuments({ status: 'borrowed' }),
      maintenanceEquipment: await Equipment.countDocuments({ status: 'maintenance' }),
      activeBorrows: await ActiveBorrow.countDocuments(),
      pendingRequests: await BorrowRequest.countDocuments({ status: 'pending' }),
      unpaidPenalties: await Penalty.countDocuments({ status: 'unpaid' })
    };
    
    if (req.session.user.role === 'user') {
      stats.myActiveBorrows = await ActiveBorrow.countDocuments({ userId: req.session.user.id });
      stats.myPenalties = await Penalty.countDocuments({ userId: req.session.user.id, status: 'unpaid' });
    }
    
    res.json({ success: true, stats });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// ============= ADMIN RESET =============
app.post('/api/admin/reset', requireRole(['admin']), async (req, res) => {
  try {
    await User.deleteMany({});
    await Equipment.deleteMany({});
    await BorrowRequest.deleteMany({});
    await ActiveBorrow.deleteMany({});
    await Penalty.deleteMany({});
    await Maintenance.deleteMany({});
    await seedDatabase();
    res.json({ success: true, message: 'Database reset successfully!' });
  } catch (error) {
    res.status(500).json({ error: 'Reset failed' });
  }
});

// ============= SERVE FRONTEND =============
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ============= START SERVER =============
seedDatabase();

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║   🚀 ASSETFLOW RUNNING ON KOYEB                              ║
║   📡 Port: ${PORT}                                            ║
║   🗄️  Database: MongoDB Atlas (Connected)                    ║
║                                                              ║
║   📋 DEMO LOGINS:                                            ║
║   👤 Student:   alex@demo.com / 123                         ║
║   👑 Admin:     pratik@demo.com / admin123                  ║
║   🔧 Technician: subash@demo.com / tech123                  ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
  `);
});